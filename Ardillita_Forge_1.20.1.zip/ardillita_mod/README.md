# Ardillita — Minecraft Forge 1.20.1

Tiny, cute tree-climbing squirrels focused on atmosphere and charm.

## Features
- Natural spawning around normal animal-friendly areas; the mob is designed to live around trees.
- Tiny voxel-style squirrel with huge cute eyes, rosy cheeks and a big fluffy tail.
- 2.5% natural chance for the pink Ardillita.
- Climbs against surfaces and foliage.
- Can make little nests in leaves.
- Tame with the custom Bellota item.
- Owner interaction with an empty hand: toggle sitting / follow / fetch mode.
- Fetch mode searches nearby dropped items and brings them to its owner.
- Cute custom chirp, happy and eating sounds.
- Breeding is supported for tamed Ardillitas.

## Controls
- Give a wild Ardillita a Bellota: attempt to tame it.
- Right-click your tamed Ardillita with an empty hand: sit / follow / fetch.
- Right-click with a Bellota: heal it.

## Build on GitHub
Upload this whole project to a GitHub repository. The included `.github/workflows/build.yml` automatically builds the Forge 1.20.1 JAR and publishes it as a workflow artifact.

The project intentionally contains fewer than 100 files.
