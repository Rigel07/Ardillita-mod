package com.ardillita.client;

import com.ardillita.ArdillitaMod;
import com.ardillita.client.model.ArdillitaModel;
import com.ardillita.client.renderer.ArdillitaRenderer;
import com.ardillita.registry.ModEntities;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ArdillitaMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    public static final ModelLayerLocation ARDILLITA_LAYER = new ModelLayerLocation(new ResourceLocation(ArdillitaMod.MOD_ID, "ardillita"), "main");

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ARDILLITA_LAYER, ArdillitaModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ARDILLITA.get(), ArdillitaRenderer::new);
    }

    private ClientSetup() {}
}
