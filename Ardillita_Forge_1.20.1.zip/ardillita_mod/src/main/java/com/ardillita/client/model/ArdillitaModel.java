package com.ardillita.client.model;

import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.util.Mth;

public class ArdillitaModel<T extends ArdillitaEntity> extends HierarchicalModel<T> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart leftEar;
    private final ModelPart rightEar;

    public ArdillitaModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.tail = root.getChild("tail");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.leftEar = head.getChild("left_ear");
        this.rightEar = head.getChild("right_ear");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.5F, -3.5F, -3F, 7F, 7F, 6F, new CubeDeformation(0.15F)), PartPose.offset(0, 17, 0));
        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 14).addBox(-3.8F, -4F, -4F, 7.6F, 7.2F, 7F, new CubeDeformation(0.1F)), PartPose.offset(0, 12, -2.2F));
        head.addOrReplaceChild("left_ear", CubeListBuilder.create().texOffs(0, 29).addBox(-1.3F, -2.8F, -0.6F, 2.6F, 3.2F, 1.4F, new CubeDeformation(0.05F)), PartPose.offset(2.2F, -3.6F, 0));
        head.addOrReplaceChild("right_ear", CubeListBuilder.create().texOffs(8, 29).addBox(-1.3F, -2.8F, -0.6F, 2.6F, 3.2F, 1.4F, new CubeDeformation(0.05F)), PartPose.offset(-2.2F, -3.6F, 0));
        root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(18, 29).addBox(-2.2F, -4.5F, -1.7F, 4.4F, 8F, 3.4F, new CubeDeformation(0.35F)), PartPose.offset(0, 16, 3.7F));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create().texOffs(0, 34).addBox(-1.2F, -1F, -1.4F, 2.4F, 3F, 2.5F, new CubeDeformation(0.08F)), PartPose.offset(2.3F, 20.2F, -1));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create().texOffs(10, 34).addBox(-1.2F, -1F, -1.4F, 2.4F, 3F, 2.5F, new CubeDeformation(0.08F)), PartPose.offset(-2.3F, 20.2F, -1));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T squirrel, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD * 0.75F;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD * 0.6F;
        this.tail.yRot = Mth.cos(ageInTicks * 0.13F) * 0.22F;
        this.tail.xRot = -0.25F + Mth.cos(ageInTicks * 0.09F) * 0.08F;
        this.leftEar.zRot = Mth.sin(ageInTicks * 0.09F) * 0.03F;
        this.rightEar.zRot = -this.leftEar.zRot;
        float walk = Mth.cos(limbSwing * 1.7F) * limbSwingAmount * 0.7F;
        this.leftLeg.xRot = walk;
        this.rightLeg.xRot = -walk;
        if (squirrel.isOrderedToSit()) {
            this.body.xRot = -0.18F;
            this.leftLeg.xRot = -0.4F;
            this.rightLeg.xRot = -0.4F;
        } else {
            this.body.xRot = 0;
        }
    }

    @Override
    public ModelPart root() { return root; }
}
