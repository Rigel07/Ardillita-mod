package com.ardillita.registry;

import com.ardillita.ArdillitaMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ArdillitaMod.MOD_ID);
    public static final RegistryObject<Item> BELLOTA = ITEMS.register("bellota", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ARDILLITA_NEST_ITEM = ITEMS.register("ardillita_nest", () -> new BlockItem(ModBlocks.ARDILLITA_NEST.get(), new Item.Properties()));
    private ModItems() {}
}
