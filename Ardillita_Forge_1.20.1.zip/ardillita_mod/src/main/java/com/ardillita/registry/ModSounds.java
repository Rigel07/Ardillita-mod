package com.ardillita.registry;

import com.ardillita.ArdillitaMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ArdillitaMod.MOD_ID);
    public static final RegistryObject<SoundEvent> ARDILLITA_CHIRP = register("ardillita_chirp");
    public static final RegistryObject<SoundEvent> ARDILLITA_HAPPY = register("ardillita_happy");
    public static final RegistryObject<SoundEvent> ARDILLITA_EAT = register("ardillita_eat");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ArdillitaMod.MOD_ID, name)));
    }
    private ModSounds() {}
}
